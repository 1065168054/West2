package west2_Test2_1;

public class IngredientSortOutException extends RuntimeException{//果汁或啤酒售空
    public IngredientSortOutException(Drinks drinks){
        System.out.println(drinks.name+"已售罄");
    }

}
