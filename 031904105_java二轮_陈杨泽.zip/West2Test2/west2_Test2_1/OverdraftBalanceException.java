package west2_Test2_1;

public class OverdraftBalanceException extends RuntimeException{
    public OverdraftBalanceException(double cost,double leftMoney){
        double need = cost - leftMoney;
        System.out.println("进货差"+need+"元");
    }

}
