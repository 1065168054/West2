package west2_Test2_1;

interface FriedChickenRestaurant{
    void saleSetMeal(int i);//出售套餐
    void bulkPurchase(int number,Drinks drinks);//批量进货
}