package west2_Test2_1;

import java.time.LocalDate;

public class Beer extends Drinks {
    protected float alcoholDegree;

    public Beer(String name, double cost, LocalDate productionDate, int shelfLife, float alcoholDegree) {
        super(name, cost, productionDate, 30);
        this.alcoholDegree = alcoholDegree;
    }

    @Override
    public boolean isExceed() {
        return super.isExceed();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Beer){
            Beer t =(Beer) obj;
            return this.name.equals(t.name);
        }

        return false;
    }
}





