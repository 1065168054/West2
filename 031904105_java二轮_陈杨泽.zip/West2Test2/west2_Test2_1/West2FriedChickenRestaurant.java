package west2_Test2_1;

import java.time.LocalDate;
import java.util.ArrayList;

public class West2FriedChickenRestaurant implements FriedChickenRestaurant {
    private double money = 1000;//餐厅余额
    public ArrayList<Beer> beers = new ArrayList<Beer>();
    public ArrayList<Juice> juices = new ArrayList<Juice>();
    public static ArrayList<SetMeal> setMeals = new ArrayList<SetMeal>();

    /*public West2FriedChickenRestaurant(double money,ArrayList<Beer> beers,ArrayList<Juice> juices, ArrayList<SetMeal> setMeals){
        this.money = money;
        this.beers = beers;
        this.juices = juices;
        this.setMeals = setMeals;
    }*/
    public void use(Beer beer) {

        if (beers.contains(beer) && !beer.isExceed()) {//有这款啤酒且不过期就卖出
            beers.remove(beer);
        } else {
            throw new IngredientSortOutException(beer);
        }

    }

    public void use(Juice juice) {
        if (juices.contains(juice) && !juice.isExceed()) {
            juices.remove(juice);
        } else {
            throw new IngredientSortOutException(juice);
        }
    }

    public double getMoney() {
        return money;
    }

    public ArrayList<Beer> getBeers() {
        return beers;
    }

    public ArrayList<Juice> getJuices() {
        return juices;
    }

    public ArrayList<SetMeal> getSetMeals() {
        return setMeals;
    }

    static {
        West2FriedChickenRestaurant stock = new West2FriedChickenRestaurant();
        Beer beer1 = new Beer("beer1", 5, LocalDate.of(2020, 12, 1), 30, 15);
        Juice juice1 = new Juice("juice1", 3, LocalDate.of(2020, 12, 13), 2);
        stock.getBeers().add(beer1);
        stock.getJuices().add(juice1);
        //本店仅提供炸鸡+啤酒套餐和炸鸡+果汁套餐
        SetMeal setMeal1 = new SetMeal("setMeal1", 25, "firedChicken1", beer1);
        stock.getSetMeals().add(setMeal1);
        SetMeal setMeal2 = new SetMeal("setMeal2", 22, "friedChicken1", juice1);
        stock.getSetMeals().add(setMeal2);
        setMeals = stock.getSetMeals();
    }

    @Override
    public void saleSetMeal(int i) {
        if (setMeals.get(i-1).drinks instanceof Beer) {
            money += setMeals.get(i-1).setMealCost;
            use((Beer)setMeals.get(i-1).drinks);
        } else {
            money += setMeals.get(i-1).setMealCost;
            use((Juice) setMeals.get(i-1).drinks);
        }
    }

    @Override
    public void bulkPurchase(int number,Drinks drinks) {

        double sumCost = drinks.cost * number;
        if (drinks instanceof Beer) {
            if (money >= sumCost) {
                money -= sumCost;
                for (int i = 1; i <= number; i++) {
                    beers.add((Beer) drinks);
                }
            }
            else {
                throw new OverdraftBalanceException(sumCost,money);
            }
        }
        else {
            if (money >= sumCost) {
                money -= sumCost;
                for (int i = 1; i <= number; i++) {
                    juices.add((Juice) drinks);
                }
            }
            else {
                throw new OverdraftBalanceException(sumCost,money);
            }
        }
    }
}