package west2_Test2_1;

import java.time.LocalDate;

public class Juice extends Drinks {
    protected Juice(String name, double cost, LocalDate productionDate, int shelfLife) {
        super(name, cost, productionDate, 2);
    }

    @Override
    protected boolean isExceed() {
        return super.isExceed();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Juice){
            Juice t =(Juice) obj;
            return this.name.equals(t.name);
        }
        return false;
    }
}
