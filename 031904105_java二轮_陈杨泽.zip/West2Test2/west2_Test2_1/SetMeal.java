package west2_Test2_1;

public class SetMeal {

    protected String setMealName;
    protected double setMealCost;
    protected String friedChickenName;
    protected Drinks drinks;
    public SetMeal(String setMealName,double setMealCost, String friedChickenName, Drinks drinks) {
        this.setMealName = setMealName;
        this.setMealCost = setMealCost;
        this.friedChickenName = friedChickenName;
        this.drinks = drinks;
    }
    @Override
    public String toString() {
        return "SetMeal{" +
                "setMealName='" + setMealName + '\'' +
                ", setMealCost=" + setMealCost +
                ", friedChickenName=" + friedChickenName +
                ", drinks=" + drinks +
                '}';
    }
}
