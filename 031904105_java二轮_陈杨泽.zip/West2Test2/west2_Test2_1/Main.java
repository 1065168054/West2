package west2_Test2_1;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args){
        System.out.println("欢迎来到西二炸鸡店");
        West2FriedChickenRestaurant west2FriedChickenRestaurant = new West2FriedChickenRestaurant();
        System.out.println("目前账户余额:");
        System.out.println(west2FriedChickenRestaurant.getMoney()+"元");
        System.out.println("进货两瓶啤酒，一瓶果汁");
        Beer beer1 =new Beer("beer1",5,LocalDate.of(2020,12,1),30,15);
        west2FriedChickenRestaurant.bulkPurchase(2,beer1);
        west2FriedChickenRestaurant.bulkPurchase(1,new Juice("juice1",3,LocalDate.of(2020,12,13),2));
        System.out.println("目前账户余额:"+west2FriedChickenRestaurant.getMoney()+"元");
        System.out.println("目前剩余啤酒:");
        for(int i=0;i<west2FriedChickenRestaurant.getBeers().size();i++)
            System.out.println(west2FriedChickenRestaurant.getBeers().get(i).toString());
        System.out.println("目前剩余果汁:");
        for(int i=0;i<west2FriedChickenRestaurant.getJuices().size();i++)
            System.out.println(west2FriedChickenRestaurant.getJuices().get(i).toString());
        System.out.println("目前套餐:");
        for(int i=0;i<west2FriedChickenRestaurant.getSetMeals().size();i++)
            System.out.println(west2FriedChickenRestaurant.getSetMeals().get(i).toString());
        System.out.println("售出'套餐一'1份");
        west2FriedChickenRestaurant.saleSetMeal(1);
        System.out.println("目前账户余额:"+west2FriedChickenRestaurant.getMoney()+"元");
    }
}
