package west2_Test2_1;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Drinks {
    protected String name;
    protected double cost;
    protected LocalDate productionDate;
    protected int shelfLife;//保质期(天)

    protected Drinks(String name, double cost, LocalDate productionDate, int shelfLife) {
        this.name = name;
        this.cost = cost;
        this.productionDate = productionDate;
        this.shelfLife = shelfLife;
    }

    protected boolean isExceed() {//是否过期
        LocalDate x = this.productionDate.plus(this.shelfLife, ChronoUnit.DAYS);
        if (x.isBefore(LocalDate.now()))
            return true;
        else
            return false;
    }

    @Override
    public String toString() {
        return "Drinks{" +
                "name='" + name + '\'' +
                ", cost=" + cost +
                ", productionDate=" + productionDate +
                ", shelfLife=" + shelfLife +
                '}';
    }
}

