package west2_Test2_2;

import java.util.Arrays;
import java.util.Scanner;

public class Multithreading {

    public static long[] ans=new long[100];
    public static void main(String[] args) throws InterruptedException {
        long num = 10000000;
        int x;
        System.out.printf("请输入要查找的数字:");
        Scanner scanner = new Scanner(System.in);
        x = scanner.nextInt();
        MyThread[] t = new MyThread[100];
        long start1 = System.currentTimeMillis();
        for(int i=0;i<100;i++){
            t[i]=new MyThread(i,x,num*i+1,(i+1)*num);
            t[i].start();
        }
        for(int i=0;i<100;i++){
            t[i].join();
        }
        long end1 = System.currentTimeMillis();
        System.out.println("计算耗时:"+(end1 - start1) + "ms");
        System.out.println("计算结果为:" + Arrays.stream(ans).sum());

    }

    static class MyThread extends Thread{
        private int x,count;
        private long start,end;
        public MyThread(int count,int x,long start,long end){
            this.count = count;
            this.x = x;
            this.start = start;
            this.end = end;
        }

        private static boolean contain(long num,int x){
            return String.valueOf(num).contains(String.valueOf(x));
        }

        @Override
        public void run() {
            for(long i =start; i<=end;i++) {
                if (contain(i,x))
                    ans[count] += i;
            }
            //System.out.println(ans);
        }
    }
}
